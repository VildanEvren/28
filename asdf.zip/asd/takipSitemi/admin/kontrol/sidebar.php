<div id="sidebar"><div id="sidebar-wrapper"> <!-- Loga ve kenar menü -->

	<h1 id="sidebar-title"><a href="#">Yönetim Paneli</a></h1>
	
		<center><a href="http://localhost/takipSitemi/admin/kontrol/index.php"><img id="logo" src="images/akinsoft_vertical1.png"  alt="Simpla Admin logo" /></a> </center>
		
		<div id="profile-links">
			Merhaba, <a href="#" title="Edit your profile">Vildan</a><br />
			<br />
			<a href="#" title="View the Site">Site Anasayfası</a> | <a href="logout.php" title="Sign Out">Çıkış</a>
		</div>        
			
		<ul id="main-nav">
				
			<li>
				<a href="index.php" class="nav-top-item no-submenu"> <!-- Alt menüler -->
				    Anasayfa
				</a>       
			</li>
				
			<li> 
				<a href="#" class="nav-top-item 
					<?php echo   $PageNe=="profil ayarları" || $PageNe=="konum"  || $PageNe=="personel"  ? 'current' : null; ?>"> 
					      Ayarlar
				</a>
		<ul>
							
				<li><a href="index.php?Go=ProfilAyarlari"<?php echo $PageNe=="profil ayarları" ? ' class="current"' : null;  ?>>Profil Ayarları</a></li>
        </ul>
				</li>
			
            </div></div> <!-- End #sidebar -->
            
            <div id="main-content"> <!-- Main Content Section with everything -->