<html>
<body>
<center>

			<h2>Hoşgeldin! Yönetici Sayfasına...</h2>
			
			<ul class="shortcut-buttons-set">
			<li>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</li>
				 <li><a class="shortcut-button" href="index.php?Go=konum"><span>
					<img src="images/icons/icon.png" alt="icon" width="25" height="35" /><br />
					Konumlar
				</span></a></li>
                
				
				<li><a class="shortcut-button" href="index.php?Go=Personel"><span>
					<img src="images/icons/clientarea-icon-large.png" alt="icon" width="35" height="35" /><br />
				Personel Kayıt</span></a></li>
				
			
				
			</ul> 
			</center>
			</body>
			</html>