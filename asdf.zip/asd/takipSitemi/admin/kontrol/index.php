<?php

      require_once 'functions/data.function.php';
	  require_once 'functions/araclar.php';
	  require_once 'functions/panel.function.php';
	  session_start();
	  ob_start();
	  
	  if(!oturum_kontrol(sGet('user'), sGet('pass'))){
		  go('../control.php');
	  }
	  
	  $Go = @get("Go");
	  
	  switch ($Go){
	    default:
	      $PageNe = "anasayfa";
	      include("header.php");
	      include("sidebar.php");
	      include("content-top.php");
	      include("panel.php");
	      include("footer.php");
	      break;
	  
	  case "":
	     $PageNe = "anasayfa";
	     include("header.php");
	     include("sidebar.php");
	     include("content-top.php");
	     include("panel.php");
	     include("footer.php");
	     break;
	 
	 
		
	case "ProfilAyarlari":
	    $PageNe = "profil ayarları";
	    include("header.php");
	    include("sidebar.php");
	    include("content-top.php");
		include("inc/ayarlar/profil.php");
	    include("footer.php");
	    break;
		
	case "konum":
	    $PageNe = "konum";
	    include("header.php");
	    include("sidebar.php");
	    include("content-top.php");
		include("inc/konum/konum.php");
	    include("footer.php");
	    break;
		
				
	case "Personel":
	    $PageNe = "personel";
	    include("header.php");
	    include("sidebar.php");
	    include("content-top.php");
		include("inc/personel/personel.php");
	    include("footer.php");
	    break;
		
	case "Kadro":
	    $PageNe = "kadro";
	    include("header.php");
	    include("sidebar.php");
	    include("content-top.php");
		include("inc/kadro/kadro.php");
	    include("footer.php");
	    break;
		
	  }
	 
     