<?php
session_start();
ob_start();
session_destroy();

header("Refresh: 2; url=uyelikGirisi.php");
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Personel Takip</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>
<div class="jumbotron">
  <div class="container text-center">
    <h1>
AKINSOFT	
</h1>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      

</nav> 

<div class="container">
  <div class="row">
    
	
    <div class="col-lg-4">
      <div class="panel panel-primary">
        <div class="panel-heading"><font color='#990066' size='3'></font></div>
     <?php  echo "<br><center>Çikiş Yaptınız. Ana Sayfaya Yönlendiriliyorsunuz...</center>"; ?>
        <br><div class="panel-footer"></div>
      </div>
    </div>
    
  </div>
</div><br>



</body>
</html>

