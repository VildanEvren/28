<?php 
 
include("ayar.php");
ob_start();
session_start();
 
$kullanici_adi = $_POST['kullanici_adi'];
$sifre = $_POST['sifre'];
 
$sql_check = mysql_query("select * from personeller where kullanici_adi='".$kullanici_adi."' and sifre='".$sifre."' ") or die(mysql_error());
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Personel Takip</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    /* Remove the jumbotron's default bottom margin */
     .jumbotron {
      margin-bottom: 0;
    }
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>
<body>

<div class="jumbotron">
  <div class="container text-center">
    <h1>
AKINSOFT	
</h1>
    <p>Personel Girişi</p>
  </div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
</nav> 

<div class="container">
  <div class="row">
    
	
    <div class="col-lg-4">
      <div class="panel panel-primary">
        <div class="panel-heading">UYARI</div>
        <?php
if(mysql_num_rows($sql_check))  {
    $_SESSION["login"] = "true";
    $_SESSION["user"] = $kullanici_adi;
    $_SESSION["pass"] = $sifre;
    header("Location:k.php");
}
else {
    if($kullanici_adi=="" or $sifre=="") {
        echo "<br><font color='#990066' size='3'><center>Lütfen personel adı veya personel şifresnizi boş bırakmayınız..! <br><a href=javascript:history.back(-1)><br>Geri Dön</a></center></font>";
    }
    else {
        echo "<br><font color='#990066' size='3'><center>Personel adı ve personel şifresnizi kontrol ediniz yanlış girdiniz..!<br><a href=javascript:history.back(-1)><br>Geri Dön</a></center></font>";
    }
}
 
ob_end_flush();
?>
        <div class="panel-footer"></div>
      </div>
    </div>
    
  </div>
</div><br>


</body>
</html>

